<?php

namespace GC\MainBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GCMainBundle extends Bundle
{
}
